## 2.2.0 (2019-04-25)
Tag: [2.2.0](https://github.com/RedHatOfficial/RedHatFont/commits/2.2.0)

- README update

## 2.1.0 (2019-04-25)
Tag: [2.1.0](https://github.com/RedHatOfficial/RedHatFont/commits/2.1.0)

- Add source files to repo to to support Google Fonts

## 2.0.0 (2019-04-17)
Tag: [2.0.0](https://github.com/RedHatOfficial/RedHatFont/commits/2.0.0)

- Update font family variations, name change to italic versions for Google fonts
- Update sass mixin: remove SVG reference, update relative path default, remove quotations from font-style
- Update license

## 1.0.0 (2019-03-27)
Tag: [1.0.0](https://github.com/RedHatOfficial/RedHatFont/commits/1.0.0)

- The "Red Hat Display" and "Red Hat Text" font families which include regular, medium, & bold weights, as well as the italic style.
